## MERN Stack Doctor Appointment Booking App

MERN Stack Doctor Appointment Booking Application using React , Redux Toolkit , AntD , Node , MongoDB 

## Features :

Separate User Interfaces for Users, Admins, Doctors

JWT Authentication and Password Hashing

Ant Design Library for UI Components,

Redux Toolkit,

Notifications Functionality for Users, Admin, and Doctors

Manage Users, Doctors, and Appointments from the Admin panel

